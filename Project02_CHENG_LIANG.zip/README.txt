This Project02 package contains 4 files,

README.txt is the document tells how to run codes.

Gedcom_rp.java is the source code, it's a java code, please compile and run it.

CHENG_LIANG_BloodTree.ged is my GEDCOM file, if you want to use my file, please place it in the same folder with source code.

ParsingResult.txt is the running result of the code, it contains the parsing result of my GEDCOM file.