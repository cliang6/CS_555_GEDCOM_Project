/**
This program's copyright belongs to CHENG LIANG.
*/


import java.lang.*;
import java.util.*;
import java.io.*;


class Gedcom_rp{
	
	public static void main(String[] args){
		String gs = new String("CHENG_LIANG_BloodTree.ged"); //Default GEDCOM file is my file.
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please input the GEDCOM file's name: ");
		if(!sc.nextLine().equals("")){
			gs = sc.nextLine();
		}
		
		readAndParse(gs);
	}
	
	
	public static void readAndParse(String fileName){
		File file = new File(fileName);
		
		
		BufferedReader reader = null;
		try{
			String rstr = new String();
			PrintWriter writer = new PrintWriter("ParsingResult.txt","UTF-8");
			
			reader = new BufferedReader(new FileReader(file));
			String tstr = null;
			int count = 0;
			
			while((tstr = reader.readLine()) != null){
				count++;
				if(count == 1){//This part is used to eliminate BOM.
					tstr = tstr.substring(3);
				}
				System.out.println("--> " + tstr);
				writer.println("--> " + tstr);
				rstr = "<-- " + gparse(tstr);
				System.out.println(rstr);
				writer.println(rstr);
			}
			reader.close();
			writer.close();
        } 
		catch(IOException e){
			e.printStackTrace();
		}
		finally{
			if(reader != null){
				try{
					reader.close();
				}
				catch (IOException e1){}
			}
		}
	}
	
	
	public static String gparse(String str){// This function is used to parsing lines.
		String[] sarr = new String[10];
		String str2 = new String();
		sarr = str.split(" ");
		str2 = sarr[0]; 
		for(int i = 1; i < sarr.length; i++){
			if(i < 3){
				str2 = str2 + "|" + sarr[i];
			}
			else{
				str2 = str2 + " " + sarr[i];
			}
			if(i == 1){
				if(sarr.length < 3){
					str2 = str2 + "|" + valid(sarr[0], sarr[1], " ") + "|";
				}
				else{
					str2 = str2 + "|" + valid(sarr[0], sarr[1], sarr[2]);
				}
			}
		}
		return str2;
	}
	
	
	public static String valid(String s1, String s2, String s3){//This function is used to judge whether this line is valid.
		
		String[] lv1 = new String[]{"NAME", "SEX", "BIRT", "DEAT", "FAMC", "FAMS", "MARR", "HUSB", "WIFE", "CHIL", "DIV"};
		
		if(s1.equals("0")){
			if(s3.equals("INDI") || s3.equals("FAM")){
				return "Y";
			}
			else if(s2.equals("HEAD") || s2.equals("TRLR") || s2.equals("NOTE")){
				return "Y";
			}
			else{
				return "N";
			}
		}
		else if(s1.equals("2")){
			if(s2.equals("DATE")){
				return "Y";
			}
			else{
				return "N";
			}
		}
		else if(s1.equals("1")){
			for(int i = 0; i < lv1.length; i++){
				if(s2.equals(lv1[i])){
					return "Y";
				}
			}
			return "N";
		}
		else{
			return "N";
		}
	}
	
	
}
